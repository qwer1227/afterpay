create PROCEDURE add_stock
  (i_cat_no in number)
  is
    cursor product_list(v_cat_no products.cat_no%type) is
    select *
    from products
    where cat_no = v_cat_no;
  begin
     DBMS_OUTPUT.ENABLE;
    for product in product_list(i_cat_no) loop
         insert into product_stocks
         (product_stock_no, product_stock_size, product_stock_amount, product_no)
         values
         (product_stock_no_seq.nextval, 'S', 10, product.product_no);
         insert into product_stocks
         (product_stock_no, product_stock_size, product_stock_amount, product_no)
         values
         (product_stock_no_seq.nextval, 'M', 10, product.product_no);
         insert into product_stocks
         (product_stock_no, product_stock_size, product_stock_amount, product_no)
         values
         (product_stock_no_seq.nextval, 'L', 10, product.product_no);
    end loop;
    
    commit;
  end;
/

